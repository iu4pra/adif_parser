# Sample logs

| File | Purpose |
|---|---|
| `minimal_1qso.adi` | One QSO: smoke test and first run for new users |
| `multi_qso_same_station.adi` | 7 QSOs with 3 stations (4 + 2 + 1): test for the "multiple QSOs per QSL" option |
| `mixed_bands_modes.adi` | 10 QSOs, different bands and modes (SSB, CW, FT8) |
| `malformed.adi` | Broken records (missing CALL, wrong length, missing EOR, UTF-8, unknown tag): test for parser error reports |

All callsigns other than IU4PRA are invented for testing purposes.
